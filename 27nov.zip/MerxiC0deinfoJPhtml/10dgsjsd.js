
  		const searchParams = new URLSearchParams(window.location.search);
  		let dda = searchParams.get('bcda');
  		let bcda = dda;
  	 